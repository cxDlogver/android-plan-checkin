"""Regression tests for transition-derived atomic requirements; synthetic evidence only."""
import copy
import unittest
import test_workflow as fixtures
import model_tools as mt
import workflow as wf
from requirement_graph import full_requirement_graph, requirement_graph, verify_coverage

class AtomicContractTests(unittest.TestCase):
    setUp = fixtures.WorkflowTests.setUp
    save = fixtures.WorkflowTests.save
    bundle_and_report = fixtures.WorkflowTests.bundle_and_report

    def baseline(self):
        if not hasattr(self, '_base'):
            self._base = fixtures.WorkflowTests.baseline(self)
        return copy.deepcopy(self._base)

    def unsupported_draft(self):
        model = self.baseline()
        model.update(phase='incomplete', entryStateIds=[], transitions=[], requirements=[])
        model['features'][0]['entryStateIds'] = []
        model['rounds'] = [{'id':'BUILD-UNSUPPORTED','kind':'build',
            'nodeIds':[s['id'] for s in model['states']], 'checks':[], 'changes':[],
            'openFrontier':[s['id'] for s in model['states']]}]
        return model

    def old_constraint(self):
        model = self.unsupported_draft()
        model['schemaVersion'] = 3
        model['requirements'] = [{
            'id':'OVERALL', 'kind':'state_constraint','title':'Overall invariant',
            'stateIds':['S0','S1'],'featureIds':['F'],'sourceRefs':[{'sourceId':'SRC','locator':'whole'}],
            'ruleIds':[], 'sourceIds':['SRC'], 'status':'draft','uiRefs':[],
            'uiApplicability':{'status':'not_applicable','reason':'Synthetic nonvisual invariant'},
            'acceptance':[{'id':'A','given':'source categories','when':'observation','then':['invariant']}]}]
        return model

    def test_one_prd_feature_can_produce_multiple_transition_requirements(self):
        model = self.baseline(); model['phase'] = 'analyzing'
        edge = copy.deepcopy(model['transitions'][0])
        edge.update(id='T2', requirementId='R2', event='another sourced event', **{'from':'S1','to':'S0'})
        req = copy.deepcopy(model['requirements'][0]);req.update(id='R2',transitionId='T2',title='return value')
        model['transitions'].append(edge);model['requirements'].append(req)
        self.assertFalse(mt.validate(model)[0])
        graph = requirement_graph(model)
        self.assertEqual(1,len(model['features']))
        self.assertEqual({'R','R2'},{n['id'] for n in graph['nodes']})
        self.assertEqual(2,graph['traversal']['totalVisits'])
        self.assertFalse(verify_coverage(model,graph))

    def test_static_constraints_do_not_replace_atomic_requirements(self):
        model=self.old_constraint()
        self.assertTrue(any('atomic transitions' in e for e in mt.validate(model)[0]))
        with self.assertRaisesRegex(ValueError,'exactly one|static constraints'):
            full_requirement_graph(model)
        with self.assertRaisesRegex(ValueError,'invalid model'):
            wf.export_bundle(model,self.run,self.run)

    def test_renaming_constraint_to_behavior_does_not_create_a_transition(self):
        model=self.old_constraint();model['requirements'][0]['kind']='behavior'
        self.assertTrue(any('transitionId' in e for e in mt.validate(model)[0]))
        with self.assertRaisesRegex(ValueError,'exactly one|reference mismatch'):
            requirement_graph(model)

    def test_draft_can_save_missing_relations_but_cannot_pass_delivery(self):
        model=self.unsupported_draft()
        self.assertFalse(mt.validate(model)[0])
        self.save(model)
        wf.export_bundle(model,self.run,self.run)
        result=wf.gate(self.run,self.run)
        self.assertEqual('failed',result['checks']['MODEL-001']['status'])
        self.assertEqual('failed',result['checks']['LINK-001']['status'])
        self.assertEqual('pending',result['checks']['FEASIBILITY-001']['status'])
        self.assertNotEqual('awaiting_final_confirmation',result['gate_status'])
        html=(self.run/'review.html').read_text(encoding='utf-8')
        self.assertIn('状态迁移分析未完成',html)
        self.assertIn('尚未确定真实起点',html)

    def test_ready_and_confirmed_cannot_use_empty_draft_exemption(self):
        for phase in ('review_ready','confirmed'):
            with self.subTest(phase=phase):
                model=self.unsupported_draft();model['phase']=phase
                self.assertTrue(any('analysis must not be empty' in e for e in mt.validate(model)[0]))
        model=self.unsupported_draft()
        self.assertTrue(any('analysis must not be empty' in e for e in mt.validate(model,ready=True)[0]))

    def test_new_transitions_require_entries_even_in_incomplete_draft(self):
        model=self.baseline();model.update(phase='incomplete',entryStateIds=[])
        self.assertTrue(any('entryStateIds' in e for e in mt.validate(model)[0]))

    def test_orphan_requirement_is_not_silently_dropped_from_graph(self):
        model=self.baseline();model['phase']='analyzing'
        orphan=copy.deepcopy(model['requirements'][0]);orphan.update(id='ORPHAN',transitionId='T')
        model['requirements'].append(orphan)
        self.assertTrue(mt.validate(model)[0])
        with self.assertRaisesRegex(ValueError,'exactly one'):
            requirement_graph(model)

    def test_bidirectional_references_cannot_be_substituted(self):
        model=self.baseline();model['requirements'][0]['transitionId']='unknown'
        with self.assertRaisesRegex(ValueError,'reference mismatch'):
            full_requirement_graph(model)
        model=self.baseline();graph=requirement_graph(model)
        model['transitions'][0]['requirementId']='unknown'
        self.assertTrue(verify_coverage(model,graph))

    def test_atomic_acceptance_cannot_mix_unrelated_state_scopes(self):
        model=self.baseline();model['phase']='analyzing'
        model['requirements'][0]['acceptance'][0]['stateIds']=['S0']
        self.assertTrue(any('acceptance must describe this transition' in e for e in mt.validate(model)[0]))

    def test_common_invariants_remain_in_facts_and_transition_acceptance(self):
        model=self.baseline();model['phase']='analyzing'
        model['states'][1]['facts'].append('value remains present at this result')
        model['requirements'][0]['acceptance'][0]['then'].append('value remains present at this result')
        self.assertFalse(mt.validate(model)[0])
        data=mt.exports(model)
        self.assertEqual(1,len(data['atomic-requirements.json']['requirements']))
        self.assertEqual('T',data['atomic-requirements.json']['requirements'][0]['transition']['id'])

    def test_single_transition_legitimately_has_no_continuation_edge(self):
        model=self.baseline();self.save(model)
        wf.export_bundle(model,self.run,self.run)
        graph=wf.read(self.run/'requirement-graph.json')
        self.assertEqual([],graph['edges'])
        self.assertEqual(1,len(graph['nodes']))
        self.assertEqual(1,graph['traversal']['totalVisits'])
        self.assertEqual('passed',wf.gate(self.run,self.run)['checks']['LINK-001']['status'])

    def test_legacy_v3_behavior_model_remains_compatible(self):
        model=self.baseline();model.update(schemaVersion=3,phase='analyzing')
        self.assertFalse(mt.validate(model)[0])
        self.assertEqual(3,mt.exports(model)['state-graph.json']['schemaVersion'])
        self.assertEqual(1,requirement_graph(model)['traversal']['totalVisits'])

    def test_contract_migration_resets_checks_without_fabricating_model_changes(self):
        old=wf.read(wf.work(self.run,'gate-contract.json'));identity=old['run_id']
        old.update(contract_version=2,model_schema_version=3)
        for check in old['checks'].values():check['status']='passed'
        wf.write(wf.work(self.run,'gate-contract.json'),old)
        wf.write(self.run/'gate-result.json',{'gate_status':'passed'})
        before=wf.file_hash(wf.work(self.run,'analysis-model.json'))
        wf.migrate_contract(self.run)
        current=wf.contract(self.run);template=wf.read(wf.TEMPLATE)
        self.assertEqual(3,current['contract_version'])
        self.assertEqual(2,current['model_schema_version'])
        self.assertEqual(identity,current['run_id'])
        self.assertEqual(template['required_rule_ids'],current['required_rule_ids'])
        self.assertEqual(template['required_criteria'],current['required_criteria'])
        self.assertEqual({'pending'},{c['status'] for c in current['checks'].values()})
        self.assertEqual(before,wf.file_hash(wf.work(self.run,'analysis-model.json')))
        self.assertFalse((self.run/'gate-result.json').exists())

    def test_synthetic_passed_review_cannot_override_empty_graph_gate(self):
        model=self.unsupported_draft();self.save(model)
        bundle,path,report=self.bundle_and_report(model)
        for row in report['criteria_results']:row['affected_ids']=['S0']
        wf.write(path,report)
        errors,pending=wf.check_review(report,model,wf.read(bundle/'manifest.json'),wf.contract(self.run),self.run)
        self.assertFalse(errors,errors);self.assertFalse(pending,pending)
        gate=wf.gate(self.run,bundle,path)
        self.assertEqual('passed',gate['checks']['MODEL-REVIEW-001']['status'])
        self.assertEqual('failed',gate['checks']['MODEL-001']['status'])
        self.assertEqual('failed',gate['checks']['LINK-001']['status'])
        self.assertEqual('failed',gate['gate_status'])

